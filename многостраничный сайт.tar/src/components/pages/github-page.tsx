'use client';

import BreadcrumbNav from '@/components/shared/breadcrumb-nav';
import SiteFooter from '@/components/shared/site-footer';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Github, ExternalLink, Copy, Check, BookOpen } from 'lucide-react';
import { useState } from 'react';

const REPO_LINKS = [
  { title: 'Standing (1947) — Original Paper', url: 'https://doi.org/10.2118/947009-G' },
  { title: 'Vasquez & Beggs (1980) — JPT', url: 'https://doi.org/10.2118/6719-PA' },
  { title: 'Glasø (1980) — JPT', url: 'https://doi.org/10.2118/8031-PA' },
  { title: 'Al-Marhoun (1988) — JPT', url: 'https://doi.org/10.2118/16994-PA' },
  { title: 'Petrosky & Farshad (1993) — SPE', url: 'https://doi.org/10.2118/26644-MS' },
];

export default function GitHubPage() {
  const [copied, setCopied] = useState(false);
  const repoUrl = 'https://github.com/vl1lin/calculators';

  const copyLink = () => {
    navigator.clipboard.writeText(repoUrl).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <div className="flex flex-col min-h-[calc(100vh-64px)]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <BreadcrumbNav currentPage="GitHub Repository" />
      </div>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 w-full pb-12 flex-1">
        {/* Repo card */}
        <Card className="mb-8">
          <CardHeader>
            <div className="flex items-start justify-between flex-wrap gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-foreground/5 flex items-center justify-center">
                  <Github className="w-6 h-6" />
                </div>
                <div>
                  <CardTitle className="text-xl">PVT Toolkit</CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">Калькуляторы PVT-свойств нефти</p>
                </div>
              </div>
              <Badge variant="outline" className="font-mono text-xs">main</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-5">
            <p className="text-sm text-muted-foreground leading-relaxed">
              Набор инструментов для расчёта PVT-свойств нефтяных систем. Включает калькуляторы газосодержания (Rs), объёмного коэффициента (Bo) и давления насыщения (Pb) с поддержкой 20+ эмпирических корреляций.
            </p>

            <div className="flex flex-wrap gap-3">
              <Button asChild className="gap-2">
                <a href={repoUrl} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="w-4 h-4" /> Открыть репозиторий
                </a>
              </Button>
              <Button variant="outline" onClick={copyLink} className="gap-2">
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                {copied ? 'Скопировано!' : 'Копировать ссылку'}
              </Button>
            </div>

            <Separator />

            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="p-3 bg-muted rounded-lg">
                <p className="text-2xl font-bold font-mono">20+</p>
                <p className="text-xs text-muted-foreground">Корреляций</p>
              </div>
              <div className="p-3 bg-muted rounded-lg">
                <p className="text-2xl font-bold font-mono">3</p>
                <p className="text-xs text-muted-foreground">Калькулятора</p>
              </div>
              <div className="p-3 bg-muted rounded-lg">
                <p className="text-2xl font-bold font-mono">1947–1993</p>
                <p className="text-xs text-muted-foreground">Годы</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* About project */}
        <Card className="mb-8">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <BookOpen className="w-4 h-4" /> О проекте
            </CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground space-y-3 leading-relaxed">
            <p>
              PVT Toolkit — образовательный проект, реализующий набор калькуляторов для расчёта основных PVT-свойств нефтяных систем. Все корреляции взяты из открытых научных публикаций и реализованы на языке TypeScript.
            </p>
            <ul className="list-disc list-inside space-y-1 ml-2">
              <li>Расчёт газосодержания (Rs) — 6 корреляций</li>
              <li>Расчёт объёмного коэффициента (Bo) — 5 корреляций с параметрическим анализом</li>
              <li>Расчёт давления насыщения (Pb) — 9 корреляций с интерактивными графиками</li>
              <li>Проверка входных параметров на границы применимости</li>
              <li>Отображение формул с помощью KaTeX</li>
              <li>Экспорт результатов в CSV</li>
            </ul>
          </CardContent>
        </Card>

        {/* Useful links */}
        <Card className="mb-8">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Полезные ссылки</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {REPO_LINKS.map(link => (
                <a
                  key={link.title}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors group"
                >
                  <span className="text-sm font-medium">{link.title}</span>
                  <ExternalLink className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                </a>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Tech stack */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Технологии</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {['Next.js', 'TypeScript', 'Tailwind CSS', 'shadcn/ui', 'Chart.js', 'KaTeX', 'Framer Motion'].map(tech => (
                <Badge key={tech} variant="secondary">{tech}</Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      </main>

      <SiteFooter />
    </div>
  );
}
