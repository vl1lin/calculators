'use client';

import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Droplets,
  Gauge,
  Waves,
  Beaker,
  BookOpen,
  AlertTriangle,
  Github,
} from 'lucide-react';
import RsCalculator from '@/components/rs-calculator';
import BoCalculator from '@/components/bo-calculator';
import PbCalculator from '@/components/pb-calculator';

export default function Home() {
  const [activeTab, setActiveTab] = useState('rs');

  return (
    <div className="min-h-screen flex flex-col">
      {/* ===== HEADER ===== */}
      <header className="sticky top-0 z-50 backdrop-blur-xl bg-background/80 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-primary flex items-center justify-center">
                <Beaker className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-lg font-bold tracking-tight leading-none">PVT Toolkit</h1>
                <p className="text-[11px] text-muted-foreground leading-none mt-0.5">Petroleum Engineering Correlations</p>
              </div>
            </div>
            <a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              <Github className="w-4 h-4" />
              <span className="hidden sm:inline">Repository</span>
            </a>
          </div>
        </div>
      </header>

      {/* ===== HERO ===== */}
      <section className="relative overflow-hidden border-b">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-primary/5" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl -translate-y-1/2" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24 text-center">
          <Badge variant="secondary" className="mb-4">
            20+ эмпирических корреляций
          </Badge>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold tracking-tight mb-4 max-w-3xl mx-auto">
            Калькуляторы PVT-свойств нефти
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8">
            Инструменты для расчета растворимости газа, объемного коэффициента нефти и давления точки пузырьков по известным корреляциям
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium">
              <Droplets className="w-4 h-4" /> Газосодержание R<sub>s</sub>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-sm font-medium">
              <Gauge className="w-4 h-4" /> Объемный коэфф. B<sub>o</sub>
            </div>
            <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-amber-500/10 text-amber-600 dark:text-amber-400 text-sm font-medium">
              <Waves className="w-4 h-4" /> Точка пузырька P<sub>b</sub>
            </div>
          </div>
        </div>
      </section>

      {/* ===== MAIN CONTENT ===== */}
      <main className="flex-1">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="w-full grid grid-cols-3 mb-8 h-auto p-1 bg-muted">
              <TabsTrigger
                value="rs"
                className="py-3 sm:py-4 flex flex-col sm:flex-row items-center gap-1.5 text-xs sm:text-sm data-[state=active]:bg-primary data-[state=active]:text-primary-foreground rounded-md transition-all"
              >
                <Droplets className="w-4 h-4" />
                <div className="text-left">
                  <span className="block font-semibold">R<sub>s</sub></span>
                  <span className="hidden sm:block text-[10px] opacity-70">Газосодержание</span>
                </div>
              </TabsTrigger>
              <TabsTrigger
                value="bo"
                className="py-3 sm:py-4 flex flex-col sm:flex-row items-center gap-1.5 text-xs sm:text-sm data-[state=active]:bg-emerald-600 data-[state=active]:text-white rounded-md transition-all"
              >
                <Gauge className="w-4 h-4" />
                <div className="text-left">
                  <span className="block font-semibold">B<sub>o</sub></span>
                  <span className="hidden sm:block text-[10px] opacity-70">Объемный коэфф.</span>
                </div>
              </TabsTrigger>
              <TabsTrigger
                value="pb"
                className="py-3 sm:py-4 flex flex-col sm:flex-row items-center gap-1.5 text-xs sm:text-sm data-[state=active]:bg-amber-500 data-[state=active]:text-white rounded-md transition-all"
              >
                <Waves className="w-4 h-4" />
                <div className="text-left">
                  <span className="block font-semibold">P<sub>b</sub></span>
                  <span className="hidden sm:block text-[10px] opacity-70">Точка пузырька</span>
                </div>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="rs">
              <RsCalculator />
            </TabsContent>
            <TabsContent value="bo">
              <BoCalculator />
            </TabsContent>
            <TabsContent value="pb">
              <PbCalculator />
            </TabsContent>
          </Tabs>

          {/* About section */}
          <Separator className="my-12" />

          <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
            <Card className="group hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <Droplets className="w-5 h-5 text-primary" />
                </div>
                <CardTitle className="text-base">Газосодержание (R<sub>s</sub>)</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <p>Растворимость газа в нефти при заданных давлении и температуре. 6 корреляций: Standing, Lasater, Vasquez & Beggs, Glasø, Al-Marhoun, Petrosky & Farshad.</p>
              </CardContent>
            </Card>
            <Card className="group hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <Gauge className="w-5 h-5 text-emerald-600" />
                </div>
                <CardTitle className="text-base">Объемный коэфф. (B<sub>o</sub>)</CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <p>Отношение объема нефти в пластовых условиях к объему на поверхности. Поддержка параметрического анализа и экспорта в CSV. 5 корреляций.</p>
              </CardContent>
            </Card>
            <Card className="group hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <Waves className="w-5 h-5 text-amber-600" />
                </div>
                <CardTitle className="text-base">Давление P<sub>b</sub></CardTitle>
              </CardHeader>
              <CardContent className="text-sm text-muted-foreground">
                <p>Давление насыщения (точка пузырька) с интерактивными графиками сравнения 9 корреляций. Ползунки для мгновенной настройки параметров.</p>
              </CardContent>
            </Card>
          </section>

          {/* Disclaimer */}
          <Card className="border-amber-200 dark:border-amber-800 bg-amber-50/50 dark:bg-amber-950/20">
            <CardContent className="pt-6">
              <div className="flex gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-amber-800 dark:text-amber-200 space-y-2">
                  <p className="font-semibold">Важное примечание</p>
                  <p>Данный калькулятор предназначен для <strong>образовательных и оценочных целей</strong>. Для проектных расчетов рекомендуется использовать специализированное ПО (Eclipse, PVTsim, CMG WinProp) и проверять данные по первоисточникам. Авторы не несут ответственности за точность расчетов и любые последствия их использования.</p>
                  <div className="flex items-center gap-1.5 text-xs">
                    <BookOpen className="w-3.5 h-3.5" />
                    <span>Все формулы основаны на опубликованных научных работах (1947–1993)</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* ===== FOOTER ===== */}
      <footer className="border-t bg-muted/30 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-3">
                <div className="w-7 h-7 rounded bg-primary flex items-center justify-center">
                  <Beaker className="w-4 h-4 text-primary-foreground" />
                </div>
                <span className="font-bold text-sm">PVT Toolkit</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Набор инструментов для расчета PVT-свойств нефти по эмпирическим корреляциям. Разработан для инженеров-нефтяников и студентов.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-sm mb-3">Калькуляторы</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><button onClick={() => setActiveTab('rs')} className="hover:text-foreground transition-colors">Газосодержание (R<sub>s</sub>)</button></li>
                <li><button onClick={() => setActiveTab('bo')} className="hover:text-foreground transition-colors">Объемный коэфф. (B<sub>o</sub>)</button></li>
                <li><button onClick={() => setActiveTab('pb')} className="hover:text-foreground transition-colors">Давление P<sub>b</sub></button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-sm mb-3">Источники</h4>
              <ul className="space-y-2 text-xs text-muted-foreground">
                <li>Standing (1947)</li>
                <li>Lasater (1958)</li>
                <li>Vasquez & Beggs (1980)</li>
                <li>Glasø (1980)</li>
                <li>Al-Marhoun (1985, 1988)</li>
                <li>Petrosky & Farshad (1993)</li>
                <li>Elam (1957), Labedi (1982), Owolabi (1984)</li>
              </ul>
            </div>
          </div>
          <Separator className="mb-6" />
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-muted-foreground">
            <p>© {new Date().getFullYear()} PVT Toolkit. Образовательный проект.</p>
            <p>Все расчеты носят оценочный характер.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
